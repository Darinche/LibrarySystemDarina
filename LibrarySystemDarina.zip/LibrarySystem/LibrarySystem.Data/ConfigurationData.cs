﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Data
{
    public static class ConfigurationData
    {
        public const string ConnectionString = "Server=.\\SQLEXPRESS; DataBase=LibrarySystem; Integrated Security=true";
    }
}
