﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace LibrarySystem.Data
{
    public class LibrarySystemDbContext: DbContext
    {
        public LibrarySystemDbContext()
        {
            this.Database.SetCommandTimeout(180);
        }
        public LibrarySystemDbContext(DbContextOptions<LibrarySystemDbContext> options):base(options)
        {
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured == false)
                optionsBuilder.UseSqlServer(ConfigurationData.ConnectionString);
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Title> Titles { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<LibraryItem> LibraryItems { get; set; }
        public object MovementOfLibraryItems { get; set; }
    }
}

