﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace LibrarySystem.Data.Models
{
    public class LibraryItem
    {
        [Key]
        public int InventoryNumberId { get; set; }
        public int TitleId { get; set; }
        public Title Title { get; set; }
        public string Condition { get; set; }
        public string LibraryItemType { get; set; }
        public string LibraryItemStorage { get; set; }
        public string Libraryitemtype { get; set; }
        public string Libraryitemstorage { get; set; }

        public LibraryItem()
        {

        }
    }
}
