﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Data.Models
{
    public class MovementOfLibraryItems
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public DateTime Return { get; set; }
        public string Type { get; set; }
        public string Reader { get; set; }
        public string Librarian { get; set; }
        public string Condotion { get; set; }
        public int LibraryItemId { get; set; }
        public LibraryItem LibraryItem { get; set; }
        public MovementOfLibraryItems()
        {
            this.Date = DateTime.UtcNow;
            this.Return = DateTime.UtcNow;
        }

        public static void Add(MovementOfLibraryItems movementoflibraryitems)
        {
            throw new NotImplementedException();
        }
    }
}
