﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibrarySystem.Data.Models
{
    public class Title
    {
        [Key]
        public int TitleId { get; set; }
        public string TitleName { get; set; }
        public string Annotation { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public int ISBN { get; set; }
        public string Type { get; set; }
        public string Image { get; set; }
        public string PublishingHouse { get; set; }
        public int SectionId { get; set; }
        public Section Section { get; set; }

        public ICollection<LibraryItem> LibrirayItems { get; set; }
        public object LibraryItems { get; set; }

        public Title()
        {
            this.LibrirayItems = new List<LibraryItem>();
        }
    }
}
