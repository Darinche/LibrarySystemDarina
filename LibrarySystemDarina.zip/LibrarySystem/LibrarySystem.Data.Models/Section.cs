﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibrarySystem.Data.Models
{
    public class Section
    {
        [Key]
        public int SectionId { get; set; }
        public string SectionName { get; set; }
        public string SectionDescription { get; set; }

        public ICollection<Title> Titles { get; set; }
        public int Id { get; set; }
        public object LibraryItems { get; set; }

        public Section() { this.Titles = new List<Title>(); }
    }
}
