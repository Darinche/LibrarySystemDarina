﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;

namespace LibrarySystem.Services
{
    public class SectionService: ISectionService
    {
        private LibrarySystemDbContext context;

        public SectionService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateSection(string name, string description)
        {
            var section = new Section() 
            {
                SectionName = name,
                SectionDescription = description
            };
            context.Sections.Add(section);
            context.SaveChanges();
            return section.SectionId;
        }
    }
}
