﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;


namespace LibrarySystem.Services
{
    public class LibraryItemService:ILibraryItemService
    {
        private LibrarySystemDbContext context;

        public LibraryItemService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateLibraryItem(string condition, string libraryitemtype, string libraryitemstorage, string title)
        {
            var titleObject = context.Titles.FirstOrDefault(x => x.TitleName == title);
            var libraryitem = new LibraryItem() 
            {
                Condition = condition,
                Libraryitemtype = libraryitemtype,
                Libraryitemstorage = libraryitemstorage,
                TitleId = titleObject.TitleId
            };
            this.context.LibraryItems.Add(libraryitem);
            titleObject.LibraryItems.Add(libraryitem);
            context.SaveChanges();
            return libraryitem.InventoryNumberId;
        }
    }
}
