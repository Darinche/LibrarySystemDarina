﻿namespace LibrarySystem.Services
{
    public interface IMovementOfLibraryItemsService
    {
    }
}