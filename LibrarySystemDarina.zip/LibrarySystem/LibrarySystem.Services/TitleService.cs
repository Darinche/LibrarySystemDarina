﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
    public class TitleService:ITitleService
    {
        private LibrarySystemDbContext context;
        public TitleService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int AddTitle(string name, string annotation, string author, int isbn, string type, string image, string publishinghouse, string section)
        {
            var sectionObject = context.Sections.FirstOrDefault(x => x.SectionName == section);
            var title = new Title() 
            {
                TitleName = name,
                Annotation=annotation,
                Author=author,
                ISBN=isbn,
                Type=type,
                Image=image,
                PublishingHouse=publishinghouse,
                SectionId=sectionObject.Id
            };
            this.context.Titles.Add(title);
            sectionObject.Titles.Add(title);
            context.SaveChanges();
            return title.SectionId;
        }
    }
}
