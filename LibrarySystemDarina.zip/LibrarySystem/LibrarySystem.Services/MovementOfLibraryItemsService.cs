﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
    public class MovementOfLibraryItemsService:IMovementOfLibraryItemsService
    {
        private LibrarySystemDbContext context;
        public MovementOfLibraryItemsService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int CreateMovementOfLibraryItems(string type, string reader, string librarian, string condotion)
        {
            var movementoflibraryitemsObject = context.Users.FirstOrDefault(x => x.MovementoflibraryitemsName == type);
            var movementoflibraryitems = new MovementOfLibraryItems() {
                Type = type,
                Reader = reader,
                Librarian = librarian,
                Condotion = condotion
            };
            this.context.MovementOfLibraryItems.Add(movementoflibraryitems);
            MovementOfLibraryItems.Add(movementoflibraryitems);
            context.SaveChanges();
            return movementoflibraryitems.Id;

        }
    }
}
