﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
    public interface ISectionService
    {
        public int CreateSection(string name, string description);
    }
}
