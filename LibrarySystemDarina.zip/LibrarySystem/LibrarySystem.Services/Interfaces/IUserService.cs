﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
    public interface IUserService
    {
        public int AddUser(string name, string password, string role, string email, string names);
    }
}
