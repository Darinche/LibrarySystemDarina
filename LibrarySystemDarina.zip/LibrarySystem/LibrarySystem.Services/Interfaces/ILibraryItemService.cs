﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
    public interface ILibraryItemService
    {
        public int CreateLibraryItem(string condition, string libraryitemtype, string libraryitemstorage, string title);
    }
}
