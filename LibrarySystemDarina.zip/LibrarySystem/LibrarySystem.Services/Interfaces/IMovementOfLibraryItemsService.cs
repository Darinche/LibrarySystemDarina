﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibrarySystem.Services.Interfaces
{
    public interface IMovementOfLibraryItemService
    {
        public int CreateMovementOfLibraryItem(string type, string reader, string librarian, string condotion);
    }
}
