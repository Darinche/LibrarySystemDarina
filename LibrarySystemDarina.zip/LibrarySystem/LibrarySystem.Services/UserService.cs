﻿using System;
using System.Collections.Generic;
using System.Text;
using LibrarySystem.Data;
using LibrarySystem.Data.Models;
using LibrarySystem.Services.Interfaces;
using System.Linq;

namespace LibrarySystem.Services
{
    public class UserService:IUserService
    {
        private LibrarySystemDbContext context;

        public UserService(LibrarySystemDbContext context)
        {
            this.context = context;
        }
        public int AddUser(string name, string password, string role, string email, string names)
        {
            var userObject = context.Users.FirstOrDefault(x => x.UserName == name);
            var user = new User()
            {
                UserName=name,
                Password=password,
                Role=role,
                Email=email,
                Names=names
            };
            this.context.Users.Add(user);
            userObject.Users.Add(user);
            context.SaveChanges();
            return user.UserId;
        }
    }
}
